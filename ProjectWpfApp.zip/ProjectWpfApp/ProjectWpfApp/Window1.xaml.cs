﻿using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using static ProjectWpfApp.MainWindow;

namespace ProjectWpfApp
{

    public partial class Window1 : Window
    {
        private string projectPicturesFolder = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Pictures");
        private string selectedImagePath = "";
        public Travel CurrentTravel { get; private set; }

        private void EnsureDirectoryExists()
        {
            if (!Directory.Exists(projectPicturesFolder))
            {
                Directory.CreateDirectory(projectPicturesFolder);
            }
        }

        public Travel NewTravel { get; private set; }
        public Window1(Travel travel = null)
        {
            InitializeComponent();
            EnsureDirectoryExists();

            if (travel != null)
            {
                CurrentTravel = travel;
                txtTitle.Text = travel.Title;
                txtCountry.Text = travel.Country;
                txtCity.Text = travel.City;
                rbYes.IsChecked = travel.IsVisited;
                myDatePicker.SelectedDate = travel.VisitStart;
                myDatePicker1.SelectedDate = travel.VisitEnd;
                txtDescription.Text = travel.Description;
                img2.Source = new BitmapImage(new Uri(travel.ImagePath, UriKind.Relative));



                btnSave.Content = "Save changes";
            }
            else
            {
                CurrentTravel = new Travel
                {
                    City = "",
                    Country = " ",
                    Description = " ",
                    ImagePath = " "
                };


            }
        }


        private void AddPhoto(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Image files|*.jpg;*.jpeg;*.png;"
            };

            if (ofd.ShowDialog() == true)
            {
                selectedImagePath = ofd.FileName;
                img2.Source = new BitmapImage(new Uri(selectedImagePath));

            }

            if (ofd.ShowDialog() == true)
            {
                string fileName = System.IO.Path.GetFileName(ofd.FileName);
                string destinationPath = System.IO.Path.Combine(projectPicturesFolder, fileName);

                try
                {
                    File.Copy(ofd.FileName, destinationPath, true); // Kopiowanie pliku
                    img2.Source = new BitmapImage(new Uri(destinationPath));

                    // Po zapisaniu, aktualizujemy główne okno
                    MainWindow mainWindow = Application.Current.Windows[0] as MainWindow;


                    MessageBox.Show("Zdjęcie zapisane w " + destinationPath, "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Błąd zapisu pliku: " + ex.Message, "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }

        }


        private void SavePhoto(object sender, RoutedEventArgs e)
        {
            string title = txtTitle.Text;
            string country = txtCountry.Text;
            string city = txtCity.Text;
            bool isVisited = rbYes.IsChecked == true;
            DateTime? visitStart = myDatePicker.SelectedDate;
            DateTime? visitEnd = myDatePicker1.SelectedDate;
            string description = txtDescription.Text;

            if (string.IsNullOrWhiteSpace(country) || string.IsNullOrWhiteSpace(city))
            {
                MessageBox.Show("Country and City are required!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (isVisited && (!visitStart.HasValue || !visitEnd.HasValue))
            {
                MessageBox.Show("Enter the date of visit!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (visitEnd > visitStart)
            {
                MessageBox.Show("Incorrectly entered date!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            NewTravel = new Travel
            {
                Title = title,
                Country = country,
                City = city,
                IsVisited = isVisited,
                VisitStart = visitStart,
                VisitEnd = visitEnd,
                Description = description,
                ImagePath = selectedImagePath  // Zapisanie ścieżki obrazu

            };
            DialogResult = true;
            Close();

            CurrentTravel.Title = txtTitle.Text;
            CurrentTravel.Country = txtCountry.Text;
            CurrentTravel.City = txtCity.Text;
            CurrentTravel.IsVisited = rbYes.IsChecked ?? false;
            CurrentTravel.VisitStart = myDatePicker.SelectedDate ?? DateTime.MinValue;
            CurrentTravel.VisitEnd = myDatePicker1.SelectedDate ?? DateTime.MinValue;
            CurrentTravel.Description = txtDescription.Text;
            if (!string.IsNullOrEmpty(selectedImagePath))
            {
                CurrentTravel.ImagePath = selectedImagePath;
            }
            else
            {
                CurrentTravel.ImagePath = null;
            }


            this.Close();
        }




        private void visited(object sender, RoutedEventArgs e)
        {

            myDatePicker.IsEnabled = true;
            myDatePicker1.IsEnabled = true;
        }

        private void no_visited(object sender, RoutedEventArgs e)
        {
            myDatePicker.IsEnabled = false;
            myDatePicker1.IsEnabled = false;
        }

        private void DelPhoto(object sender, RoutedEventArgs e)
        {
            selectedImagePath = string.Empty;
            MessageBoxResult messageBoxResult = MessageBox.Show("Photo won't be saved");

        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
