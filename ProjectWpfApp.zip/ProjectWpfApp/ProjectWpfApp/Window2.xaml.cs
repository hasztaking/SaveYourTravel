﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ProjectWpfApp
{
    /// <summary>
    /// Logika interakcji dla klasy Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private Random random = new Random();
        public Window2()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;

        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Ustawienie startowej pozycji przycisku
            EscapeButton.SetValue(Canvas.LeftProperty, (double)(random.Next(0, (int)(MainGrid.ActualWidth - EscapeButton.Width))));
            EscapeButton.SetValue(Canvas.TopProperty, (double)(random.Next(0, (int)(MainGrid.ActualHeight - EscapeButton.Height))));
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void EscapeButton_MouseEnter(object sender, MouseEventArgs e)
        {
            double newX = random.Next(0, (int)(MainGrid.ActualWidth - EscapeButton.Width));
            double newY = random.Next(0, (int)(MainGrid.ActualHeight - EscapeButton.Height));

            // Przesuwamy przycisk do nowej pozycji
            EscapeButton.SetValue(Canvas.LeftProperty, newX);
            EscapeButton.SetValue(Canvas.TopProperty, newY);
        }
    }
}
