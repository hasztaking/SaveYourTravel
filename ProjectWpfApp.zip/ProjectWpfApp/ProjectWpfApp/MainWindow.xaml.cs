﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace ProjectWpfApp
{

    public partial class MainWindow : Window
    {


        public class Travel
        {
            public string Title { get; set; }
            public required string Country { get; set; } = "Unknown";
            public required string City { get; set; } = "Unknown";
            public bool IsVisited { get; set; } = false;
            public DateTime? VisitStart { get; set; } = DateTime.MinValue;
            public DateTime? VisitEnd { get; set; } = DateTime.MinValue.AddDays(1);
            public required string Description { get; set; } = "";
            public string ImagePath { get; set; } = "/pictures/1.jpg";


            public override string ToString()
            {

                if (Title != null)
                {
                    return $"{Title}\n {Country}, {City}\n";
                }
                else
                {
                    return $"{Country}, {City}\n";
                }
            }
        }



        private List<Travel> travels = new List<Travel>();

        public MainWindow()
        {
            InitializeComponent();
            DefaultTravel();

        }

        private void DefaultTravel()
        {
            travels.Add(item: new Travel
            {
                Title = "Study",
                Country = "Poland",
                City = "Opole",
                IsVisited = false,
                Description = " something interesting about Opole ",
                ImagePath = "C:\\Users\\nowak\\OneDrive - The Opole University of Technology\\programowanie\\ProjectWpfApp\\ProjectWpfApp\\pictures\\Opole.jpg"
            });

            travelList.ItemsSource = travels;
            travelList.SelectedItem = travels[0];
        }



        private void DisplayCountry(Travel travel)
        {
            country.Text = travel.Country;
        }

        private void DisplayCity(Travel travel)
        {
            city.Text = travel.City;
        }

        private void DisplayFrom(Travel travel)
        {
            if (travel.IsVisited)
            {
                from.Text = travel.VisitStart.ToString();
            }
            else
            {
                from.Text = "Not visited yet";
            }
        }

        private void DisplayTo(Travel travel)
        {
            if (travel.IsVisited)
            {
                to.Text = travel.VisitEnd.ToString();
            }
            else
            {
                to.Text = "Not visited yet";
            }
        }
        private void DisplayDescr(Travel travel)
        {
            descr.Text = travel.Description;
        }


        private void AddT(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();


            if (window1.ShowDialog() == true)
            {
                Travel travel = window1.NewTravel;
                travels.Add(travel);  // Dodanie podróży do listy
                travelList.ItemsSource = null;
                travelList.ItemsSource = travels;
            }
        }



        private void TravelList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (travelList.SelectedIndex >= 0)  // Sprawdza, czy coś jest wybrane
            {
                Travel selectedTravel = travels[travelList.SelectedIndex];  // Pobiera wybraną podróż

                DisplayCountry(selectedTravel);
                DisplayCity(selectedTravel);
                DisplayFrom(selectedTravel);
                DisplayTo(selectedTravel);
                DisplayDescr(selectedTravel);

                if (!string.IsNullOrEmpty(selectedTravel.ImagePath))
                {
                    imgHolder.Source = new BitmapImage(new Uri(selectedTravel.ImagePath));  // Ładuje obraz podróży
                }
                else
                {
                    imgHolder.Source = null;  // Usuwa obraz, jeśli brak
                }
            }

        }

        private void DeleteTravel(object sender, RoutedEventArgs e)
        {
            if (travelList != null)
            {
                Travel selectedTravel = (Travel)travelList.SelectedItem;
                travels.Remove(selectedTravel);

                travelList.ItemsSource = null;
                travelList.ItemsSource = travels;

            }
        }

        private void EditTravel(object sender, RoutedEventArgs e)
        {
            if (travelList.SelectedItem is Travel selectedTravel)
            {
                Window1 editWindow = new Window1(selectedTravel);
                if (editWindow.ShowDialog() == true)
                {
                    travelList.ItemsSource = null;
                    travelList.ItemsSource = travels;
                }
            }
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Minimalize(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
    }
}